# Rock-cloner
i customized version /updated
---

## Overview
This project was made to make your life easier, instead of spending hours trying to make your server as beautiful as possible you can simply clone a server with this tool / fixed + updated


## How to use? 
```typescript
$ pnpm i
# or
$ npm i
# or
$ yarn add
```
**Examples with tsx**
```typescript
$ pnpm i -g tsx
# or
$ npm i -g tsx
```

```typescript
$ tsx .
```
**You can also use [codesandbox](https://codesandbox.io/dashboard/recent) to start the cloner**
## Termux/Mobile
```Termux/moblie
$ git clone https://github.com/devrock07/rock-cloner.git
$ cd rock-cloner
$ npm i
$ npm i -g tsx
$ tsx .
```
----

### Thank you for your support!
